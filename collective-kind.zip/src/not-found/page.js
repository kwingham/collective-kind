"use client";

export default function NotFound() {
  return (
    <div>
      <h2>404</h2>
      <p>Page not found. Please check the URL and try again.</p>
    </div>
  );
}
