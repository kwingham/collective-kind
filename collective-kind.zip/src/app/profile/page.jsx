"use client";

import { useEffect, useState } from "react";
import { supabase } from "../lib/supabaseClient";

export default function ProfilePage() {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchProfile() {
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .limit(1);

      if (error) {
        console.error("Error fetching profile:", error);
      } else {
        setProfile(data[0]);
      }
      setLoading(false);
    }

    fetchProfile();
  }, []);

  if (loading) {
    return <p>Loading...</p>;
  }

  return (
    <div>
      {profile ? (
        <div>
          <h2>{profile.username}</h2>
          <p>{profile.bio}</p>
        </div>
      ) : (
        <p>No profile data available.</p>
      )}
    </div>
  );
}
