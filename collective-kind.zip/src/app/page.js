export default function Home() {
  return (
    <div>
      <h2>Home</h2>
      <p>Welcome in, I am because we are</p>
    </div>
  );
}
